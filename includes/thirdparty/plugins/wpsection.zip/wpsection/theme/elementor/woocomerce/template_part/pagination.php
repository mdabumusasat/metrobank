       
 <?php
if ($enable_pagination) {
    echo '<div class="wps_pagination_priduct_area">';
    bosch_the_pagination2(array(
        'total' => $query->max_num_pages,
        'next_text' => '<i class="eicon-arrow-right"></i> ',
        'prev_text' => '<i class="eicon-arrow-left"></i>'
    ));
    echo '</div>';
}
?>
                                 