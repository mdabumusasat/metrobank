<?php


use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;

class wps_tesimonial_slide_Widget extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'wps_tesimonial_slide';
    }

    public function get_title()
    {
        return __('Testimonial Slide', 'wpssupport');
    }

    public function get_icon()
    {
        return 'eicon-testimonial-carousel';
    }

    public function get_keywords()
    {
        return ['wps', 'Testimonial'];
    }

    public function get_categories()
    {
        return ['wpsection_category'];
    }



    protected function register_controls()
    {
        $this->start_controls_section(
            'testimonial',
            [
                'label' => esc_html__('Testimonial', 'Testimonial'),
            ]
        );
        $this->add_control(
            'sec_class',
            [
                'label'       => __('Section Class', 'Testimonial'),
                'type'        => Controls_Manager::TEXTAREA,
                'dynamic'     => [
                    'active' => true,
                ],
                'placeholder' => __('Enter Section Class', 'Testimonial'),
            ]
        );
        $this->add_control(
            'wps_columns',
            array(
                'label' => __('Columns Settings', 'wpsection'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '1'  => __('1 Column', 'wpsection'),
                    '2' => __('2 Columns', 'wpsection'),
                    '3' => __('3 Columns', 'wpsection'),
                    '4' => __('4 Columns', 'wpsection'),
                    '5' => __('5 Columns', 'wpsection'),
                ],
            )
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'number_of_stars',
            [
                'label'     => esc_html__('Number of Stars', 'greengia'),
                'type'      => Controls_Manager::SELECT,
                'default'   => '5', // Default number of stars
                'options'   => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                ],
            ]
        );
        $repeater->add_control(
            'block_image',
            [
                'label' => __('Image', 'rashid'),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => Utils::get_placeholder_image_src(),],
            ]
        );
        $repeater->add_control(
            'block_title',
            [
                'label' => esc_html__('Name', 'rashid'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Enter your title', 'rashid'),
            ]
        );
        $repeater->add_control(
            'block_subtitle',
            [
                'label' => esc_html__('Designation', 'rashid'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Enter your Subtitle', 'rashid'),
            ]
        );
        $repeater->add_control(
            'block_text',
            [
                'label' => esc_html__('Text', 'rashid'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Enter your Text', 'rashid'),
            ]
        );
        $this->add_control(
            'repeater',
            [
                'label' => esc_html__('Repeater List', 'wpsection'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_title' => esc_html__('Title #1', 'wpsection'),
                        'list_content' => esc_html__('Item content. Click the edit button to change this text.', 'wpsection'),
                    ],
                ],
            ]
        );


        $this->end_controls_section();
        $this->start_controls_section(
            'section_icon_style',
            [
                'label' => esc_html__('Icon Setting', 'wpsection'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'show_icon',
            array(
                'label' => esc_html__('Show Icon', 'ecolabe'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'show' => [
                        'show' => esc_html__('Show', 'ecolab'),
                        'icon' => 'eicon-check-circle',
                    ],
                    'none' => [
                        'none' => esc_html__('Hide', 'ecolab'),
                        'icon' => 'eicon-close-circle',
                    ],
                ],
                'default' => 'show',
                'selectors' => array(
                    '{{WRAPPER}} .mr_block_title' => 'display: {{VALUE}} !important',
                ),
            )
        );


        $this->add_control(
            'star_color',
            [
                'label'     => esc_html__('Star Color', 'greengia'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#f39c12', // Default color for stars
                'default' => 'center',
                'condition'    => array('show_icon' => 'show'),
                'selectors' => array(
                    '{{WRAPPER}} .rating i' => 'text-align: {{VALUE}} !important',
                ),
            ]
        );
        $this->add_control(
            'icon_alingment',
            array(
                'label' => esc_html__('Alignment', 'ecolab'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'ecolab'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'ecolab'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'ecolab'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'condition'    => array('show_icon' => 'show'),
                'toggle' => true,
                'selectors' => array(
                    '{{WRAPPER}} .rating' => 'text-align: {{VALUE}} !important',
                ),
            )
        );
        $this->add_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 24,
                    'unit' => 'px',
                ],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'condition'    => array('show_icon' => 'show'),
                'selectors' => [
                    '{{WRAPPER}} .rating i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'word_spacing',
            [
                'label' => __('Word Spacing', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 5,
                    'unit' => 'px',
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                        'step' => 1,
                    ],
                ],
                'condition'    => array('show_icon' => 'show'),
                'selectors' => [
                    '{{WRAPPER}} .rating' => 'word-spacing: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'line_height',
            [
                'label' => __('Line Height', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 1.5,
                    'unit' => 'em',
                ],
                'range' => [
                    'em' => [
                        'min' => 0.1,
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'condition'    => array('show_icon' => 'show'),
                'selectors' => [
                    '{{WRAPPER}} .rating i' => 'line-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'content_section_three',
            [
                'label' => __('Text Setting', 'rashid'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
            'show_text',
            array(
                'label' => esc_html__('Show Text', 'ecolab'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'show' => [
                        'show' => esc_html__('Show', 'ecolab'),
                        'icon' => 'eicon-check-circle',
                    ],
                    'none' => [
                        'none' => esc_html__('Hide', 'ecolab'),
                        'icon' => 'eicon-close-circle',
                    ],
                ],
                'default' => 'show',
                'selectors' => array(
                    '{{WRAPPER}} .mr_f_block_text' => 'display: {{VALUE}} !important',
                ),
            )
        );

        $this->add_control(
            'text_alingment',
            array(
                'label' => esc_html__('Alignment', 'ecolab'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'ecolab'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'ecolab'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'ecolab'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'condition'    => array('show_text' => 'show'),
                'toggle' => true,
                'selectors' => array(
                    '{{WRAPPER}} .mr_f_block_text' => 'text-align: {{VALUE}} !important',
                ),
            )
        );
        $this->add_control(
            'text_margin',
            array(
                'label'     => __('Margin', 'wpsection'),
                'condition'    => array('show_text' => 'show'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>  ['px', '%', 'em'],
                'selectors' => array(
                    '{{WRAPPER}} .mr_f_block_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );
        $this->add_control(
            'text_padding',
            array(
                'label'     => __('Padding', 'ecolab'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' =>  ['px', '%', 'em'],
                'condition'    => array('show_text' => 'show'),
                'selectors' => array(
                    '{{WRAPPER}} .mr_f_block_text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name'     => 'text_typography',
                'condition'    => array('show_text' => 'show'),
                'label'    => __('Typography', 'ecolab'),
                'selector' => '{{WRAPPER}} .mr_f_block_text',
            )
        );
        $this->add_control(
            'text_color',
            array(
                'label'     => __('Color', 'ecolab'),
                'condition'    => array('show_text' => 'show'),
                'separator' => 'after',
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .mr_f_block_text' => 'color: {{VALUE}} !important',
                ),
            )
        );
        $this->add_control(
            'text_hover_color',
            array(
                'label'     => __('Hover Color', 'ecolab'),
                'condition'    => array('show_text' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .mr_featured_block:hover ' => 'color: {{VALUE}} !important',
                ),
            )
        );


        $this->end_controls_section();
        $this->start_controls_section(
            'thumbnail_control',
            array(
                'label' => __('Image Settings', 'wpsection'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'show_thumbnail',
            array(
                'label' => esc_html__('Show Button', 'wpsection'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'show' => [
                        'show' => esc_html__('Show', 'wpsection'),
                        'icon' => 'eicon-check-circle',
                    ],
                    'none' => [
                        'none' => esc_html__('Hide', 'wpsection'),
                        'icon' => 'eicon-close-circle',
                    ],
                ],
                'default' => 'show',
                'selectors' => array(
                    '{{WRAPPER}} .mr_product_thumb' => 'display: {{VALUE}} !important',
                ),
            )
        );

        $this->add_control(
            'text_alingment1',
            array(
                'label' => esc_html__('Alignment', 'ecolab'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'ecolab'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'ecolab'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'ecolab'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'condition'    => array('show_thumbnail' => 'show'),
                'toggle' => true,
                'selectors' => array(
                    '{{WRAPPER}} .mr_product_block' => 'text-align: {{VALUE}} !important',
                ),
            )
        );
        $this->add_control(
            'thumbnail_padding',
            array(
                'label'     => __('Padding', 'wpsection'),
                'condition'    => array('show_thumbnail' => 'show'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>  ['px', '%', 'em'],

                'selectors' => array(
                    '{{WRAPPER}} .mr_product_thumb' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );

        $this->add_control(
            'thumbnail_x_margin',
            array(
                'label'     => __('Margin', 'wpsection'),
                'condition'    => array('show_thumbnail' => 'show'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>  ['px', '%', 'em'],
                'selectors' => array(
                    '{{WRAPPER}} .mr_product_thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'thumbnail_border',
                'condition'    => array('show_thumbnail' => 'show'),
                'selector' => '{{WRAPPER}} .mr_product_thumb',
            )
        );

        $this->add_control(
            'thumbnail_border_radius',
            array(
                'label'     => __('Border Radius', 'wpsection'),
                'condition'    => array('show_thumbnail' => 'show'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' =>  ['px', '%', 'em'],
                'selectors' => array(
                    '{{WRAPPER}} .mr_product_thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_testimonial_style',
            [
                'label' => esc_html__('Title Setting', 'wpsection'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'show_title',
            array(
                'label' => esc_html__('Show Title', 'ecolabe'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'show' => [
                        'show' => esc_html__('Show', 'ecolab'),
                        'icon' => 'eicon-check-circle',
                    ],
                    'none' => [
                        'none' => esc_html__('Hide', 'ecolab'),
                        'icon' => 'eicon-close-circle',
                    ],
                ],
                'default' => 'show',
                'selectors' => array(
                    '{{WRAPPER}} .mr_block_title' => 'display: {{VALUE}} !important',
                ),
            )
        );
        $this->add_control(
            'title_alingment',
            array(
                'label' => esc_html__('Alignment', 'ecolab'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'ecolab'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'ecolab'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'ecolab'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'condition'    => array('show_title' => 'show'),
                'toggle' => true,
                'selectors' => array(

                    '{{WRAPPER}} .mr_block_title' => 'text-align: {{VALUE}} !important',
                ),
            )
        );


        $this->add_control(
            'title_padding',
            array(
                'label'     => __('Padding', 'ecolab'),
                'condition'    => array('show_title' => 'show'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' =>  ['px', '%', 'em'],

                'selectors' => array(
                    '{{WRAPPER}} .mr_block_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );
        $this->add_control(
            'title_margin',
            array(
                'label'     => __('Margin', 'wpsection'),
                'condition'    => array('show_title' => 'show'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>  ['px', '%', 'em'],
                'selectors' => array(
                    '{{WRAPPER}} .mr_block_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name'     => 'title_typography',
                'condition'    => array('show_title' => 'show'),
                'label'    => __('Typography', 'ecolab'),
                'selector' => '{{WRAPPER}} .mr_block_title',
            )
        );
        $this->add_control(
            'title_color',
            array(
                'label'     => __('Color', 'ecolab'),
                'condition'    => array('show_title' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .mr_block_title' => 'color: {{VALUE}} !important',

                ),
            )
        );
        $this->add_control(
            'title_hover_color',
            array(
                'label'     => __('Color Hover', 'ecolab'),
                'condition'    => array('show_title' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .mr_featured_block:hover' => 'color: {{VALUE}} !important',

                ),
            )
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_subtitle_style',
            [
                'label' => esc_html__('SubTitle Setting', 'wpsection'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'show_subtitle',
            array(
                'label' => esc_html__('Show Sub Title', 'ecolabe'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'show' => [
                        'show' => esc_html__('Show', 'ecolab'),
                        'icon' => 'eicon-check-circle',
                    ],
                    'none' => [
                        'none' => esc_html__('Hide', 'ecolab'),
                        'icon' => 'eicon-close-circle',
                    ],
                ],
                'default' => 'show',
                'selectors' => array(
                    '{{WRAPPER}} .mr_block_subtitle' => 'display: {{VALUE}} !important',
                ),
            )
        );
        $this->add_control(
            'subtitle_alingment',
            array(
                'label' => esc_html__('Alignment', 'ecolab'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'ecolab'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'ecolab'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'ecolab'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'condition'    => array('show_subtitle' => 'show'),
                'toggle' => true,
                'selectors' => array(

                    '{{WRAPPER}} .mr_block_subtitle' => 'text-align: {{VALUE}} !important',
                ),
            )
        );


        $this->add_control(
            'subtitle_padding',
            array(
                'label'     => __('Padding', 'ecolab'),
                'condition'    => array('show_subtitle' => 'show'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' =>  ['px', '%', 'em'],

                'selectors' => array(
                    '{{WRAPPER}} .mr_block_subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name'     => 'subtitle_typography',
                'condition'    => array('show_subtitle' => 'show'),
                'label'    => __('Typography', 'ecolab'),
                'selector' => '{{WRAPPER}} .mr_block_subtitle',
            )
        );
        $this->add_control(
            'subtitle_color',
            array(
                'label'     => __('Color', 'ecolab'),
                'condition'    => array('show_subtitle' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .mr_block_subtitle' => 'color: {{VALUE}} !important',

                ),
            )
        );
        $this->add_control(
            'subtitle_hover_color',
            array(
                'label'     => __('Color Hover', 'ecolab'),
                'condition'    => array('show_subtitle' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .mr_featured_block_subtitle:hover' => 'color: {{VALUE}} !important',

                ),
            )
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'block_settings',
            array(
                'label' => __('Block Setting', 'wpsection'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );


        $this->add_control(
            'show_block',
            array(
                'label' => esc_html__('Show Block', 'wpsection'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'show' => [
                        'show' => esc_html__('Show', 'wpsection'),
                        'icon' => 'eicon-check-circle',
                    ],
                    'none' => [
                        'none' => esc_html__('Hide', 'wpsection'),
                        'icon' => 'eicon-close-circle',
                    ],
                ],
                'default' => 'show',
                'selectors' => array(
                    '{{WRAPPER}} .mr_product_block' => 'display: {{VALUE}} !important',
                ),
            )
        );

        $this->add_control(
            'block_color',
            array(
                'label'     => __('Background Color', 'wpsection'),
                'condition'    => array('show_block' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .mr_product_block' => 'background: {{VALUE}} !important',
                ),
            )
        );
        $this->add_control(
            'block_hover_color',
            array(
                'label'     => __('Hover Color', 'wpsection'),
                'condition'    => array('show_block' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .mr_product_block:hover' => 'background: {{VALUE}} !important',
                ),
            )
        );

        $this->add_control(
            'block_margin',
            array(
                'label'     => __('Block Margin', 'wpsection'),
                'condition'    => array('show_block' => 'show'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' =>  ['px', '%', 'em'],

                'selectors' => array(
                    '{{WRAPPER}}  .mr_product_block' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );

        $this->add_control(
            'block_padding',
            array(
                'label'     => __('Block Padding', 'wpsection'),
                'condition'    => array('show_block' => 'show'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' =>  ['px', '%', 'em'],

                'selectors' => array(
                    '{{WRAPPER}}  .mr_product_block' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'block_shadow',
                'condition'    => array('show_block' => 'show'),
                'label' => esc_html__('Box Shadow', 'wpsection'),
                'selector' => '{{WRAPPER}} .mr_product_block',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'block_X_hover_shadow',
                'condition'    => array('show_block' => 'show'),
                'label' => esc_html__('Hover Box Shadow', 'wpsection'),
                'selector' => '{{WRAPPER}} .mr_product_block:hover',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'block_border',
                'condition'    => array('show_block' => 'show'),
                'label' => esc_html__('Box Border', 'wpsection'),
                'selector' => '{{WRAPPER}} .mr_product_block',
            ]
        );

        $this->add_control(
            'block_border_radius',
            array(
                'label'     => __('Border Radius', 'wpsection'),
                'condition'    => array('show_block' => 'show'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' =>  ['px', '%', 'em'],
                'selectors' => array(
                    '{{WRAPPER}} .mr_product_block' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'slider_path_button_3_control',
            array(
                'label' => __('Slider Arrow  Settings', 'wpsection'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'slider_path_show_button_3',
            array(
                'label' => esc_html__('Show Button', 'wpsection'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'show' => [
                        'show' => esc_html__('Show', 'wpsection'),
                        'icon' => 'eicon-check-circle',
                    ],
                    'none' => [
                        'none' => esc_html__('Hide', 'wpsection'),
                        'icon' => 'eicon-close-circle',
                    ],
                ],
                'default' => 'show',
                'selectors' => array(
                    '{{WRAPPER}} .slider_path .owl-nav ' => 'display: {{VALUE}} !important',
                ),
            )
        );

        $this->add_control(
            'slider_path_button_3_color',
            array(
                'label'     => __('Button Color', 'wpsection'),
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default' => '#cbcbcb',
                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-nav .owl-prev' => 'color: {{VALUE}} !important',
                    '{{WRAPPER}}  .slider_path .owl-nav .owl-next' => 'color: {{VALUE}} !important',

                ),
            )
        );
        $this->add_control(
            'slider_path_button_3_color_hover',
            array(
                'label'     => __('Button Hover Color', 'wpsection'),
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff ',
                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-nav .owl-prev:hover' => 'color: {{VALUE}} !important',
                    '{{WRAPPER}}  .slider_path .owl-nav .owl-next:hover' => 'color: {{VALUE}} !important',

                ),
            )
        );
        $this->add_control(
            'slider_path_button_3_bg_color',
            array(
                'label'     => __('Background Color', 'wpsection'),
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default' => '#f3f3f3 ',
                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-nav button' => 'background: {{VALUE}} !important',
                ),
            )
        );
        $this->add_control(
            'slider_path_button_3_hover_color',
            array(
                'label'     => __('Background Hover Color', 'wpsection'),
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default' => '#222',
                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-nav button:hover' => 'background: {{VALUE}} !important',
                ),
            )
        );



        $this->add_control(
            'slider_path_dot_3_width',
            [
                'label' => esc_html__('Arraw Width',  'wpsection'),
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider_path .owl-nav .owl-prev' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .slider_path .owl-nav .owl-next' => 'width: {{SIZE}}{{UNIT}};',
                ]

            ]
        );


        $this->add_control(
            'slider_path_dot_3_height',
            [
                'label' => esc_html__('Arraw Height', 'wpsection'),
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider_path .owl-nav .owl-prev' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .slider_path .owl-nav .owl-next ' => 'height: {{SIZE}}{{UNIT}};',

                ]
            ]
        );



        $this->add_control(
            'slider_path_button_3_padding',
            array(
                'label'     => __('Padding', 'wpsection'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'size_units' =>  ['px', '%', 'em'],

                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-nav button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );

        $this->add_control(
            'slider_path_button_3_margin',
            array(
                'label'     => __('Margin', 'wpsection'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'size_units' =>  ['px', '%', 'em'],
                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-nav button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name'     => 'slider_path_button_3_typography',
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'label'    => __('Typography', 'wpsection'),
                'selector' => '{{WRAPPER}}  .slider_path .owl-nav button',
            )
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'slider_path_border_3',
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'selector' => '{{WRAPPER}}  .slider_path .owl-nav .owl-prev, .slider_path .owl-nav .owl-next ',
            )
        );


        $this->add_control(
            'slider_path_border_3_radius',
            array(
                'label'     => __('Border Radius', 'wpsection'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'size_units' =>  ['px', '%', 'em'],

                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-nav button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'label' => esc_html__('Box Shadow', 'wpsection'),
                'selector' => '{{WRAPPER}} .slider_path .owl-nav button',
            ]
        );



        $this->add_control(
            'slider_path_horizontal_prev',
            [
                'label' => esc_html__('Horizontal Position Previous',  'wpsection'),
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider_path .owl-nav .owl-prev' => 'left: {{SIZE}}{{UNIT}};',
                ]

            ]
        );
        $this->add_control(
            'slider_path_horizontal_next',
            [
                'label' => esc_html__('Horizontal Position Next', 'wpsection'),
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider_path .owl-nav .owl-next' => 'right: {{SIZE}}{{UNIT}};',
                ],

            ]
        );

        $this->add_control(
            'slider_path_vertical',
            [
                'label' => esc_html__('Vertical Position', 'wpsection'),
                'condition'    => array('slider_path_show_button_3' => 'show'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider_path ' => 'top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .slider_path .owl-nav ' => 'top: {{SIZE}}{{UNIT}};',
                ]
            ]
        );


        $this->end_controls_section();



        // Dot Button Setting

        $this->start_controls_section(
            'slider_path_dot_control',
            array(
                'label' => __('Slider Dot  Settings', 'wpsection'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,

            )
        );

        $this->add_control(
            'slider_path_show_dot',
            array(
                'label' => esc_html__('Show Dot', 'wpsection'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'show' => [
                        'show' => esc_html__('Show', 'wpsection'),
                        'icon' => 'eicon-check-circle',
                    ],
                    'none' => [
                        'none' => esc_html__('Hide', 'wpsection'),
                        'icon' => 'eicon-close-circle',
                    ],
                ],
                'default' => 'show',
                'selectors' => array(
                    '{{WRAPPER}} .slider_path .owl-dots ' => 'display: {{VALUE}} !important',
                ),
            )
        );


        $this->add_control(
            'slider_path_dot_width',
            [
                'label' => esc_html__('Dot Width',  'wpsection'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'condition'    => array('slider_path_show_dot' => 'show'),
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider_path .owl-theme .owl-dots span' => 'width: {{SIZE}}{{UNIT}};',
                ]

            ]
        );

        $this->add_control(
            'slider_path_dot_height',
            [
                'label' => esc_html__('Dot Height', 'wpsection'),
                'condition'    => array('slider_path_show_dot' => 'show'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider_path .owl-theme .owl-dots span ' => 'height: {{SIZE}}{{UNIT}};',

                ]
            ]
        );

        $this->add_control(
            'slider_path_dot_color',
            array(
                'label'     => __('Dot Color', 'wpsection'),

                'type'      => \Elementor\Controls_Manager::COLOR,
                'default' => '#222',
                'condition'    => array('slider_path_show_dot' => 'show'),
                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-theme .owl-dots .owl-dot span' => 'background: {{VALUE}} !important',

                ),
            )
        );
        $this->add_control(
            'slider_path_dot_color_hover',
            array(
                'label'     => __('Dot Hover Color', 'wpsection'),

                'type'      => \Elementor\Controls_Manager::COLOR,
                'condition'    => array('slider_path_show_dot' => 'show'),
                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-theme .owl-dots .owl-dot span:hover' => 'background: {{VALUE}} !important',

                ),
            )
        );
        $this->add_control(
            'slider_path_dot_bg_color',
            array(
                'label'     => __('Active Color', 'wpsection'),

                'type'      => \Elementor\Controls_Manager::COLOR,
                'default' => '#fff',
                'condition'    => array('slider_path_show_dot' => 'show'),
                'selectors' => array(
                    '{{WRAPPER}}  .owl-theme .owl-dots .owl-dot.active span' => 'background: {{VALUE}} !important',
                ),
            )
        );

        $this->add_control(
            'slider_path_dot_padding',
            array(
                'label'     => __('Padding', 'wpsection'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>  ['px', '%', 'em'],
                'condition'    => array('slider_path_show_dot' => 'show'),
                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-theme .owl-dots .owl-dot span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );

        $this->add_control(
            'slider_path_dot_margin',
            array(
                'label'     => __('Margin', 'wpsection'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>  ['px', '%', 'em'],
                'condition'    => array('slider_path_show_dot' => 'show'),
                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-theme .owl-dots .owl-dot span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'slider_path_dot_border',
                'condition'    => array('slider_path_show_dot' => 'show'),
                'selector' => '{{WRAPPER}}  .slider_path .owl-theme .owl-dots .owl-dot span',
            )
        );


        $this->add_control(
            'slider_path_dot_radius',
            array(
                'label'     => __('Border Radius', 'wpsection'),
                'type'      => \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>  ['px', '%', 'em'],
                'condition'    => array('slider_path_show_dot' => 'show'),
                'selectors' => array(
                    '{{WRAPPER}}  .slider_path .owl-theme .owl-dots .owl-dot span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
                ),
            )
        );




        $this->add_control(
            'slider_path_dot_horizontal',
            [
                'label' => esc_html__('Horizontal Position Previous',  'wpsection'),
                'condition'    => array('slider_path_show_dot' => 'show'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider_path .owl-theme .owl-dots' => 'left: {{SIZE}}{{UNIT}};',
                ]

            ]
        );


        $this->add_control(
            'slider_path_dot_vertical',
            [
                'label' => esc_html__('Vertical Position', 'wpsection'),
                'condition'    => array('slider_path_show_dot' => 'show'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider_path .owl-theme .owl-dots  ' => 'top: {{SIZE}}{{UNIT}};',

                ]
            ]
        );


        $this->end_controls_section();
    }

    /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
?>


        <?php
        echo '
        <script>
          jQuery(document).ready(function($)
          {
            //put the js code under this line 
            //three-item-carousel
            if ($(".three-item-carousel").length) {
              $(".three-item-carousel").owlCarousel({
                loop:true,
                margin:30,
                nav:true,
                smartSpeed: 500,
                autoplay: true, // Corrected autoplay value
                navText: ["<span class=\'eicon-arrow-left\'></span>", "<span class=\'eicon-arrow-right\'></span>"],
                responsive:{
                  0:{
                    items:1
                  },
                  480:{
                    items:1
                  },
                  600:{
                    items:2
                  },
                  800:{
                    items:3
                  },
                  1200:{
                    items:' . esc_js($settings['wps_columns']) . '
                  }
                }
              });    		
            }
          });
        </script>';

        ?>


        <section class="testimonial-section centred<?php echo esc_attr($settings['sec_class']); ?>">
            <div class="auto-container">
                <div class="three-item-carousel owl-carousel slider_path owl-theme owl-dots nav-style-one">
                    <?php foreach ($settings['repeater'] as $item) : ?>
                        <div class="testimonial-block-one mr_product_block">
                            <div class="inner-box">
                                <div class="text-box">

                                    <ul class="rating clearfix">
                                        <?php
                                        $rating = $item['number_of_stars'];
                                        $full_stars = $rating > 0 ? $rating : 0;
                                        $empty_stars = 5 - $full_stars;

                                        for ($rs = 1; $rs <= $full_stars; $rs++) {
                                            echo '<li class="mr_star_full"><i class="eicon-star"></i></li>';
                                        }
                                        for ($rns = 1; $rns <= $empty_stars; $rns++) {
                                            echo '<li class="mr_star_empty"><i class="eicon-star-o"></i></li>';
                                        }
                                        ?>
                                    </ul>
                                    <p class="mr_f_block_text mr_featured_block"><?php echo wp_kses($item['block_text'], $allowed_tags); ?></p>

                                    <figure class="thumb-box"><?php if (wp_get_attachment_url($item['block_image']['id'])) : ?>
                                            <img class="mr_product_thumb" src="<?php echo wp_get_attachment_url($item['block_image']['id']); ?>" alt="">
                                        <?php else : ?>
                                            <div class="noimage"></div>
                                        <?php endif; ?>
                                    </figure>
                                </div>
                                <div class="author-box">
                                    <h3 class="mr_block_title mr_featured_block"><?php echo wp_kses($item['block_title'], $allowed_tags); ?></h3>
                                    <span class="designation mr_block_subtitle mr_featured_block_subtitle"><?php echo wp_kses($item['block_subtitle'], $allowed_tags); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

<?php
    }
}

// Register widget
Plugin::instance()->widgets_manager->register(new \wps_tesimonial_slide_Widget());
