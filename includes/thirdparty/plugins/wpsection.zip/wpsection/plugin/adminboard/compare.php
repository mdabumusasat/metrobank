<div class="wpsection_compare">
		
<h2><?php esc_html_e( 'Check Free Vs Pro ', 'wpsection' ); ?></h2><br>		
	


    <table>
        <h2>Pro Version is not Ready Yet We will let you know once it will be ready. Thanks</h2>
    </table>    

    </div>
<br>
<div class="link-btn"><a href="<?php echo esc_attr(WPSECTION_PLUGIN_PRO) ; ?>" class="btn-style-one" target="_blank"><span> <?php esc_html_e( 'Buy Pro Now!', 'wpsection' ); ?></span></a></div> 