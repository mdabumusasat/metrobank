<div class="wps_widget_list">
  
  <div class="wps_widget">

 <ul>
                
  <li>
                    <img class="wps_png" src="<?php echo plugins_url('assets/widget/accordion.png', dirname(__FILE__)); ?>"  alt="">
                    <img class="wps_gif" src="<?php echo plugins_url('assets/widget/accordion.gif', dirname(__FILE__)); ?>" alt="">
                    <h5>Accordion</h5>
                </li>

  <li>
                    <img class="wps_png" src="<?php echo plugins_url('assets/widget/power-button.png', dirname(__FILE__)); ?>"  alt="">
                    <img class="wps_gif" src="<?php echo plugins_url('assets/widget/power-button.gif', dirname(__FILE__)); ?>" alt="">
                    <h5>Creative Button</h5>
                </li>

  <li>
                    <img class="wps_png" src="<?php echo plugins_url('assets/widget/information.png', dirname(__FILE__)); ?>"  alt="">
                    <img class="wps_gif" src="<?php echo plugins_url('assets/widget/information.gif', dirname(__FILE__)); ?>" alt="">
                    <h5>Counter Up</h5>
                </li>

 <li>
                    <img class="wps_png" src="<?php echo plugins_url('assets/widget/controls.png', dirname(__FILE__)); ?>"  alt="">
                    <img class="wps_gif" src="<?php echo plugins_url('assets/widget/controls.gif', dirname(__FILE__)); ?>" alt="">
                    <h5>Heading</h5>
                </li>

     <li>
                    <img class="wps_png" src="<?php echo plugins_url('assets/widget/encryption.png', dirname(__FILE__)); ?>"  alt="">
                    <img class="wps_gif" src="<?php echo plugins_url('assets/widget/encryption.gif', dirname(__FILE__)); ?>" alt="">
                    <h5>Info Box</h5>
                </li>


    <li>
                    <img class="wps_png" src="<?php echo plugins_url('assets/widget/price.png', dirname(__FILE__)); ?>"  alt="">
                    <img class="wps_gif" src="<?php echo plugins_url('assets/widget/price.gif', dirname(__FILE__)); ?>" alt="">
                    <h5>Pricing and Packages</h5>
                </li>

   <li>
                    <img class="wps_png" src="<?php echo plugins_url('assets/widget/loading.png', dirname(__FILE__)); ?>"  alt="">
                    <img class="wps_gif" src="<?php echo plugins_url('assets/widget/loading.gif', dirname(__FILE__)); ?>" alt="">
                    <h5>Progress Bar</h5>
                </li>

              
          <li>
                    <img class="wps_png" src="<?php echo plugins_url('assets/widget/diagram.png', dirname(__FILE__)); ?>"  alt="">
                    <img class="wps_gif" src="<?php echo plugins_url('assets/widget/diagram.gif', dirname(__FILE__)); ?>" alt="">
                    <h5>Social Icon</h5>
                </li>          
               

 <li>
                    <img class="wps_png" src="<?php echo plugins_url('assets/widget/teamwork.png', dirname(__FILE__)); ?>"  alt="">
                    <img class="wps_gif" src="<?php echo plugins_url('assets/widget/teamwork.gif', dirname(__FILE__)); ?>" alt="">
                    <h5>Team</h5>
                </li>
 <li>
                     <img class="wps_png" src="<?php echo plugins_url('assets/widget/ab-testing.png', dirname(__FILE__)); ?>"  alt="">
                    <img class="wps_gif" src="<?php echo plugins_url('assets/widget/ab-testing.gif', dirname(__FILE__)); ?>" alt="">
                    <h5>Footer</h5>
                </li>






           
            </ul>
</div>
</div>

  