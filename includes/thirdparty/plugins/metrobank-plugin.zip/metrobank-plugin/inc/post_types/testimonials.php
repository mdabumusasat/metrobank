<?php
/**
 * Abstract class for register post type
 */

namespace METROBANKPLUGIN\Inc\Post_Types;

use METROBANKPLUGIN\Inc\Abstracts\Post_Type;

if ( ! function_exists( 'add_action' ) ) {
	exit;
}

class Testimonials extends Post_Type {

	protected $post_type = 'metrobank_testimonials';

	protected $menu_icon = 'dashicons-portfolio';

	protected $taxonomies = array();

	public static $instance;

	public static function instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
	public static function init() {

		self::instance()->menu_name = esc_html__( 'Testimonials', 'metrobank' );
		self::instance()->singular  = esc_html__( 'Testimonial', 'metrobank' );
		self::instance()->plural    = esc_html__( 'Testimonials', 'metrobank' );
		self::instance()->supports  = array( 'title', 'editor', 'excerpt','thumbnail' );

		add_action( 'init', array( self::instance(), 'register' ) );
	}


}
