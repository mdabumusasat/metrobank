<?php

namespace METROBANKPLUGIN\Element;


class Elementor {
	static $widgets = array(
		
		'portfolios',
		'portfolios2',
		'blog_grid',

		
	);

	static function init() {
		add_action( 'elementor/init', array( __CLASS__, 'loader' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_cats' ) );
	}

	static function loader() {

		foreach ( self::$widgets as $widget ) {

			$file = METROBANKPLUGIN_PLUGIN_PATH . '/elementor/' . $widget . '.php';
			if ( file_exists( $file ) ) {
				require_once $file;
			}

			add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'register' ) );
		}
	}

	static function register( $elemntor ) {
		foreach ( self::$widgets as $widget ) {
			$class = '\\METROBANKPLUGIN\\Element\\' . ucwords( $widget );

			if ( class_exists( $class ) ) {
				$elemntor->register_widget_type( new $class );
			}
		}
	}

	static function register_cats( $elements_manager ) {

		$elements_manager->add_category(
			'metrobank',
			[
				'title' => esc_html__( 'Metrobank', 'metrobank' ),
				'icon'  => 'fa fa-plug',
			]
		);
		$elements_manager->add_category(
			'csslatepath',
			[
				'title' => esc_html__( 'Template Path', 'metrobank' ),
				'icon'  => 'fa fa-plug',
			]
		);

	}
}

Elementor::init();