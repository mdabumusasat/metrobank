<?php

return array(
	'id'     => 'metrobank_banner_settings',
	'title'  => esc_html__( "Metrobank Banner Settings", "konia" ),
	'fields' => array(
		
		array(
			'id'       => 'banner_page_banner',
			'type'     => 'switch',
			'title'    => esc_html__( 'Hide Banner', 'metrobank' ),
			'default'  => false,
			
		),
		
		
		/*
		array(
			'id'      => 'banner_source_type',
			'type'    => 'button_set',
			'title'   => esc_html__( 'Banner Source Type', 'metrobank' ),
			'options' => array(
				'd' => esc_html__( 'Default', 'metrobank' ),
				'e' => esc_html__( 'Elementor', 'metrobank' ),
			),
			'default' => 'd',
		),
		
		array(
			'id'       => 'banner_elementor_template',
			'type'     => 'select',
			'title'    => __( 'Template', 'metrobank' ),
			'data'     => 'posts',
			'args'     => [
				'post_type' => [ 'elementor_library' ],
				'posts_per_page'=> -1,
			],
			'required' => [ 'banner_source_type', '=', 'e' ],
		),
	

		array(
			'id'       => 'banner_banner_title',
			'type'     => 'text',
			'title'    => esc_html__( 'Banner Section Title', 'metrobank' ),
			'desc'     => esc_html__( 'Enter the title to show in banner section', 'metrobank' ),
			'required' => array( 'banner_page_banner', '=', true ),
		),
		*/
		array(
        'id'               => 'banner_banner_title',
        'type'             => 'editor',
        'title'            => __('Banner Title', 'metrobank'), 
        'subtitle'         => __('Subtitle text would go here.', 'metrobank'),
        'default'          => '',
	
        'args'   => array(
            'teeny'            => true,
            'textarea_rows'    => 10
        )
    ),
		
		
/*
		array(
        'id'       => 'title_color',
        'type'     => 'color',
        'title'    => __('Page Title Color', 'metrobank'), 
        'subtitle' => __('Pick a color for the theme (default: #fff).', 'metrobank'),
        'default'  => '#FFFFFF',
        'validate' => 'color',
    ),
		
	
		
	array(
        'id'          => 'title_typography',
        'type'        => 'typography', 
        'title'       => __('Banner Title Settings', 'metrobank'),
        'google'      => true, 
        'font-backup' => true,
        'output'      => array('.mr_banner_title.mr_xpost','.mr_banner_title.mr_xpage'),
        'units'       =>'px',
        'subtitle'    => __('Typography option with each property can be called individually.', 'redux-framework-demo'),
	
        'default'     => array(
            'color'       => '', 
            'font-style'  => '', 
            'google'      => true,
            'font-size'   => '', 
            'line-height' => ''
        ),
    ),	
	
	*/
	array(
			'id'       => 'title_hide',
			'type'     => 'switch',
			'title'    => esc_html__( 'Hide Title', 'metrobank' ),
			'default'  => false,
		
	),	
		
/*
	array(
        'id'          => 'bread_typography',
        'type'        => 'typography', 
        'title'       => __('Bread Crumb Settings', 'metrobank'),
        'google'      => true, 
        'font-backup' => true,
        'output'      => array('.mr_bread_list.mr_xpost_bread li.breadcrumb-item, .mr_bread_list.mr_xpost_bread li.breadcrumb-item a'),
        'units'       =>'px',
        'subtitle'    => __('Typography option with each property can be called individually.', 'redux-framework-demo'),
	
        'default'     => array(
            'color'       => '', 
            'font-style'  => '', 
            'google'      => true,
            'font-size'   => '', 
            'line-height' => ''
        ),
    ),		
	*/
	array(
			'id'       => 'hide_breadcrumb',
			'type'     => 'switch',
			'title'    => esc_html__( 'Hide Bread Crumb', 'metrobank' ),
			'default'  => false,	
	),	
	/*
		array(
			'id'       => 'banner_page_background',
			'type'     => 'media',
			'url'      => true,
			'title'    => esc_html__( 'Background Image', 'metrobank' ),
			'desc'     => esc_html__( 'Insert background image for banner', 'metrobank' ),
			'default'  => array(
				'url' => METROBANK_URI . 'assets/images/breadcrumb/breadcrumb-1.jpg',
			),
		
		),	
		
		*/
	 array(         
        'id'       => 'bgsetting',
        'type'     => 'background',
        'title'    => __('Page Title Background', 'redux-framework-demo'),
		'output'      => array('.mr_post_post.mr_page_title','.mr_page_page_title.page-title','.mr_index_index_title.mr_page_title',),
        'subtitle' => __('Body background with image, color, etc.', 'redux-framework-demo'),
        'desc'     => __('This is the description field, again good for additional info.', 'redux-framework-demo'),
	
		 
        'default'  => array(
            'background-color' => '',
        )
    )	
	
	
	
		
		
	),
);