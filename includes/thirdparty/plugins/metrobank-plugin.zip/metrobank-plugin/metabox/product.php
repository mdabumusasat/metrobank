<?php
return array(
	'title'      => 'Shop Product Meta',
	'id'         => 'metrobank_meta_product',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'product' ),
	'sections'   => array(
		array(
			'id'     => 'metrobank_product_meta_setting',
			'fields' => array(
				
				 array(
                    'id' => 'meta_image',
                    'type' => 'media',
                    'title' => esc_html__( 'Brand Image', 'metrobank' ),
                ),
				
				
				array(
					'id'    => 'meta_subtitle',
					'type'  => 'text',
					'title' => esc_html__( 'Subtitle', 'metrobank' ),
				),
				array(
					'id'    => 'page_link',
					'type'  => 'text',
					'title' => esc_html__( 'Page Link', 'metrobank' ),
				),
				array(
					'id'    => 'image_link',
					'type'  => 'text',
					'title' => esc_html__( 'Image Link', 'metrobank' ),
				),
				array(
					'id'    => 'meta_number',
					'type'  => 'text',
					'title' => esc_html__( 'Column Number', 'metrobank' ),
					'default' => esc_html__( '3', 'metrobank' ),
				),
			),
		),
	),
);