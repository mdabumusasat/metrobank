<?php
return array(
	'title'      => 'Metrobank Team Setting',
	'id'         => 'metrobank_meta_team',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'metrobank_team' ),
	'sections'   => array(
		array(
			'id'     => 'metrobank_team_meta_setting',
			'fields' => array(
				array(
					'id'    => 'designation',
					'type'  => 'text',
					'title' => esc_html__( 'Designation', 'metrobank' ),
				),
				array(
					'id'    => 'team_link',
					'type'  => 'text',
					'title' => esc_html__( 'Read More Link', 'metrobank' ),
				),
				array(
					'id'    => 'social_profile',
					'type'  => 'social_media',
					'title' => esc_html__( 'Social Profiles', 'metrobank' ),
				),
			),
		),
	),
);