<?php
return array(
	'title' => 'metrobank Post Setting',
	'id' => 'metrobank_meta_post',
	'icon' => 'el el-cogs',
	'position' => 'normal',
	'priority' => 'core',
	'post_types' => array( 'post' ),
	'sections' => array(
		array(
			'id' => 'metrobank_post_meta_setting',
			'fields' => array(
				array(
					'id' => 'meta_image',
					'type' => 'media',
					'title' => esc_html__( 'Meta image', 'indext' ),
				),
				

			),
		),
	),
);