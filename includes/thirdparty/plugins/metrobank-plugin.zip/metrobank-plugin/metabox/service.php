<?php
return array(
	'title'      => 'Metrobank Service Setting',
	'id'         => 'metrobank_meta_service',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'metrobank_service' ),
	'sections'   => array(
		array(
			'id'     => 'metrobank_service_meta_setting',
			'fields' => array(
				array(
					'id'       => 'service_icon',
					'type'     => 'select',
					'title'    => esc_html__( 'Service Icons', 'metrobank' ),
					'options'  => get_fontawesome_icons(),
				),
				array(
					'id'    => 'ext_url',
					'type'  => 'text',
					'title' => esc_html__( 'Enter Read More Link', 'metrobank' ),
				),
			),
		),
	),
);