<?php
if ( ! function_exists( "metrobank_add_metaboxes" ) ) {
	function metrobank_add_metaboxes( $metaboxes ) {
		$directories_array = array(
			'page.php',
			'projects.php',
			//'service.php',
			'team.php',
			//'testimonials.php',
			//'event.php',
			'post.php',
			'product.php',
			//'index.php',
		);
		foreach ( $directories_array as $dir ) {
			$metaboxes[] = require_once( METROBANKPLUGIN_PLUGIN_PATH . '/metabox/' . $dir );
		}

		return $metaboxes;
	}

	add_action( "redux/metaboxes/metrobank_options/boxes", "metrobank_add_metaboxes" );
}

