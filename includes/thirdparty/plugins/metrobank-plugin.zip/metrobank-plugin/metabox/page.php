<?php
return array(
	'title'      => 'Theme Setting',
	'id'         => 'metrobank_meta',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'page', 'post', 'metrobank_project','product' ),
	'sections'   => array(
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/metabox/header.php',
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/metabox/banner.php',
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/metabox/sidebar.php',
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/metabox/footer.php',
	
	),
);