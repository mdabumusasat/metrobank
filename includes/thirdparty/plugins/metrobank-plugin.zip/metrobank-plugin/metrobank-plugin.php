<?php
/**
 * Plugin Name: Metrobank Plugin
 * Plugin URI: https://profiles.wordpress.org/rashid87/
 * Description: Supported plugin for Metrobank WordPress theme
 * Author: MahfuzRashid
 * Version: 1.0
 * Author URI: https://profiles.wordpress.org/rashid87/
 *
 * @package metrobank-plugin
 */

defined( 'METROBANKPLUGIN_PLUGIN_PATH' ) || define( 'METROBANKPLUGIN_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'METROBANK_PLUGIN_URI', plugins_url( 'metrobank-plugin' ) . '/' );
require_once plugin_dir_path( __FILE__ ) . 'file_crop.php';
function metrobank_bunch_widget_init2()
{
	//Blog Widget
	if( class_exists( 'Metrobank_Latest_Post' ) )register_widget( 'Metrobank_Latest_Post' );
	
	
}
add_action( 'widgets_init', 'metrobank_bunch_widget_init2' );	

class METROBANKPLUGIN_Plugin_Core {

	/**
	 * The instance variable.
	 *
	 * @var [type]
	 */
	public static $instance;

	/**
	 * The main constructor
	 */
	function __construct() {
		self::includes();
		$this->init();

	}

	/**
	 * Load the instance.
	 *
	 * @return [type] [description]
	 */
	public static function instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public static function includes() {
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/inc/helpers/functions.php';
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/elementor/elementor.php';
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/inc/abstracts/class-post-type-abstract.php';
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/inc/abstracts/class-taxonomy-abstract.php';
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/inc/helpers/widgets.php';
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/inc/post_types/project.php';
		require_once METROBANKPLUGIN_PLUGIN_PATH . '/inc/taxonomies.php';
		
		if ( ! class_exists( 'Redux' ) ) {
			require_once METROBANKPLUGIN_PLUGIN_PATH . 'redux-framework/redux-core/framework.php';
			require_once METROBANKPLUGIN_PLUGIN_PATH . '/metabox/metaboxes.php';
		}

	}

	function init() {
		METROBANKPLUGIN\Inc\Post_Types\Project::init();
		

		add_action( 'init', array( '\METROBANKPLUGIN\Inc\Taxonomies', 'init' ) );
	}
}

/**
 * [metrobank_get_sidebars description]
 *
 * @param  boolean $multi [description].
 *
 * @return [type]         [description]
 */
function metrobanks_get_sidebars( $multi = false ) {
	global $wp_registered_sidebars;

	$sidebars = ! ( $wp_registered_sidebars ) ? get_option( 'wp_registered_sidebars' ) : $wp_registered_sidebars;

	if ( $multi ) {
		$data[] = array( 'value' => '', 'label' => 'No Sidebar' );
	} else {
		$data = array( '' => esc_html__( 'No Sidebar', 'hlc' ) );
	}

	foreach ( ( array ) $sidebars as $sidebar ) {

		if ( $multi ) {

			$data[] = array( 'value' => metrobank_set( $sidebar, 'id' ), 'label' => metrobank_set( $sidebar, 'name' ) );
		} else {

			$data[ metrobank_set( $sidebar, 'id' ) ] = metrobank_set( $sidebar, 'name' );
		}
	}

	return $data;
}


function METROBANKPLUGIN_P() {

	if ( ! isset( $GLOBALS['METROBANKPLUGIN_Plugin_p'] ) ) {
		$GLOBALS['METROBANKPLUGIN_Plugin'] = METROBANKPLUGIN_Plugin_Core::instance();
	}

	return $GLOBALS['METROBANKPLUGIN_Plugin'];
}

METROBANKPLUGIN_P();
if ( ! function_exists( 'metrobank_set' ) ) {

	function metrobank_set( $var, $key, $def = '' ) {
		/*if (!$var)
		return false;*/

		if ( is_object( $var ) && isset( $var->$key ) ) {
			return $var->$key;
		} elseif ( is_array( $var ) && isset( $var[ $key ] ) ) {
			return $var[ $key ];
		} elseif ( $def ) {
			return $def;
		} else {
			return false;
		}
	}

}

function metrobank_fontawesome_icons() {


	$pattern = '/\.(fa-(?:\w+(?:-)?)+):before\s*{\s*content/';

	$subject = wp_remote_get( get_template_directory_uri() . '/assets/css/font-awesome.min.css' );

	preg_match_all( $pattern, metrobank_set( $subject, 'body' ), $matches, PREG_SET_ORDER );
	$icons = array();
	foreach ( $matches as $match ) {
		$new_val            = ucwords( str_replace( 'fa-', '', $match[1] ) );
		$icons[ $match[1] ] = ucwords( str_replace( '-', ' ', $new_val ) );
	}

	return $icons;


}
function metrobank_encrypt( $param ) {
	return base64_encode( $param );
}

function metrobank_decrypt( $param ) {
	return base64_decode( $param );
}
function metrobank_taxonomy_regster($name, $post_type, $args) {
	// Register the taxonomy now so that the import works!
	register_taxonomy(
		$data['taxonomy'],
		apply_filters( 'woocommerce_taxonomy_objects_' . $data['taxonomy'], array( 'product' ) ),
		apply_filters( 'woocommerce_taxonomy_args_' . $data['taxonomy'], array(
			'hierarchical' => true,
			'show_ui'      => false,
			'query_var'    => true,
			'rewrite'      => false,
		) )
	);
}

add_filter('templatepath_elemnetor/modules/list', function($modules){
	$list = array('gallery', 'instagram', 'team', 'dynamic-pots', 'responsive-header', 'progress-bar', 'form', 'nav-menu', 'misc', 'audio', 'flickr', 'tabs-slider', 'testimonial');

	$modules = array_merge($modules, $list);

	return array_filter($modules);
});

error_reporting(0) ;